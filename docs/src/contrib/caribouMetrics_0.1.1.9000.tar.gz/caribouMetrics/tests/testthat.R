library(testthat)
library(caribouMetrics)

test_check("caribouMetrics")
