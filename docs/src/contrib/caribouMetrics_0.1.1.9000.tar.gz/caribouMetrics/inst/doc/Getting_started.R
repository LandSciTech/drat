## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, results=FALSE-----------------------------------------------------
knitr::opts_chunk$set(warning = FALSE)

library(caribouMetrics)
library(dplyr)
library(raster)
library(sf)
library(ggplot2)


## ----data in------------------------------------------------------------------
# load data sets 
pth_base <- system.file("extdata", package = "caribouMetrics")

caribouRanges <- c("Pagwachuan", "Missisa", "Nipigon", "James Bay")

landCover <- raster(file.path(pth_base, "landCover.tif")) %>%
  reclassPLC()

esker <- read_sf(file.path(pth_base, "esker.shp"))

linFeat <- list(roads = read_sf(file.path(pth_base, 
                                       "roads.shp")),
                rail = read_sf(file.path(pth_base, "rail.shp")),
                utilities = read_sf(file.path(pth_base, "utilities.shp")))

natDist <- sf::st_read(file.path(pth_base, "fireAFFES2020.shp")) %>% 
  reclassDist(endYr = 2020, numCumYrs = 30, template = landCover, 
              dateField = "FIRE_YEAR")

anthroDist <- raster(file.path(pth_base, "anthroDist.tif"))

# make a polygon inside the bounding box of the rasters
singlePoly <- (raster::extent(landCover) - 30000) %>% st_bbox() %>%
  st_as_sfc() %>% st_as_sf() %>% st_set_crs(st_crs(landCover))


## ----single example, warning=FALSE--------------------------------------------
carHab1 <- caribouHabitat(
  landCover = landCover,
  esker = esker,
  linFeat = linFeat,
  natDist = natDist,
  anthroDist = anthroDist,
  projectPoly = singlePoly,
  caribouRange = "Nipigon", 
  padProjPoly = TRUE
)


## ----results1-----------------------------------------------------------------
str(carHab1, max.level = 2, give.attr = FALSE)
results(carHab1)

## ----plot1, fig.width=8-------------------------------------------------------
plot(carHab1, season = c("Fall", "Summer"))

## ----multi example, fig.width=8-----------------------------------------------
# split the area into 4 polygons
corners <- rbind(st_coordinates(singlePoly)[1:4,1:2],
                 st_centroid(singlePoly) %>% st_coordinates())

projectPoly <- st_sf(Range = caribouRanges,
                     geometry = st_sfc(st_polygon(list(corners[c(1,2,5, 1),])),
                                       st_polygon(list(corners[c(2,3,5, 2),])),
                                       st_polygon(list(corners[c(3,4,5, 3),])),
                                       st_polygon(list(corners[c(4,1,5, 4),])))) %>% 
  st_set_crs(st_crs(singlePoly))

plot(projectPoly, key.pos = 1)

caribouRange <- data.frame(Range = caribouRanges, 
                           coefRange = caribouRanges, 
                           stringsAsFactors = FALSE)

MultRange <- caribouHabitat(landCover = landCover,
                            esker = esker, 
                            linFeat = linFeat,  
                            natDist = natDist,
                            anthroDist = anthroDist,
                            projectPoly = projectPoly, 
                            caribouRange = caribouRange, 
                            padProjPoly = TRUE)

## ----results2, fig.width=8, fig.height=5--------------------------------------
str(MultRange, max.level = 2, give.attr = FALSE)
results(MultRange)

plot(MultRange, season = c("Winter", "Spring"))

## ----disturbance--------------------------------------------------------------
disturb <- disturbanceMetrics(landCover = landCover,
                              linFeat = linFeat,  
                              natDist = natDist,
                              projectPoly = singlePoly)

## ----results3-----------------------------------------------------------------
str(disturb, max.level = 2, give.attr = FALSE)
results(disturb)

## ----demographics-------------------------------------------------------------
demCoefs <- demographicCoefficients(replicates = 10)

# Compare the current conditions to a scenario with 10% more anthropogenic
# disturbance
exTable <- bind_rows(results(disturb),
                     results(disturb) %>% 
                       mutate(Anthro = Anthro + 10, 
                              Total_dist = Total_dist + 10))

demRates <- demographicRates(covTable = exTable,
                             popGrowthPars = demCoefs)

ggplot(demRates, aes(Anthro, S_bar))+
  geom_point()+
  geom_errorbar(aes(ymin = S_PIlow, ymax = S_PIhigh), width = 0.1)+
  scale_y_continuous(breaks = 5:10/10, limits = c(0.5,1))+
  xlab("Anthropogenic Disturbance (%)")+
  ylab("Adult Female Survival")+
  theme_bw()


## -----------------------------------------------------------------------------
popGrow <- popGrowthJohnson(N = c(2000, 2000), numSteps = 20,
                            R_bar = demRates$R_bar, 
                            S_bar = demRates$S_bar)

cbind(demRates[,1:5], popGrow)

