## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(caribouMetrics)
library(dplyr)
library(raster)
library(sf)
pthBase <- system.file("extdata", package = "caribouMetrics")

## ----load data----------------------------------------------------------------
# load example data and classify plc into Resource Types
landCoverD = raster(file.path(pthBase, "landCover.tif")) %>% 
  reclassPLC()
eskerDras = raster(file.path(pthBase, "eskerTif.tif"))
eskerDshp = st_read(file.path(pthBase, "esker.shp"), quiet = TRUE, agr = "constant")
natDistD = raster(file.path(pthBase, "natDist.tif"))
anthroDistD = raster(file.path(pthBase, "anthroDist.tif"))
linFeatDras = raster(file.path(pthBase, "linFeatTif.tif"))
projectPolyD = st_read(file.path(pthBase, "projectPoly.shp"), quiet = TRUE, 
                       agr = "constant")
linFeatDshp = st_read(file.path(pthBase, "roads.shp"), quiet = TRUE, agr = "constant")
railD = st_read(file.path(pthBase, "rail.shp"), quiet = TRUE, agr = "constant")
utilitiesD = st_read(file.path(pthBase, "utilities.shp"), quiet = TRUE, agr = "constant")

## ----caribouHabitat1----------------------------------------------------------
carHab1 <- caribouHabitat(
  landCover = landCoverD , 
  esker = eskerDras, 
  natDist = natDistD, 
  anthroDist = anthroDistD, 
  linFeat = linFeatDras, 
  projectPoly = projectPolyD,
  caribouRange = "Nipigon"
)

## ----plot1, fig.width=8, fig.height=5-----------------------------------------
plot(carHab1, season = c("Fall", "Summer"))

## ----create projPoly----------------------------------------------------------
ext <- raster::extent(landCoverD) - 30000
projectPolyD2 <- st_bbox(ext) %>% st_as_sfc() %>% st_as_sf() %>% st_set_crs(st_crs(landCoverD))

## ----caribouHabitat2----------------------------------------------------------
carHab2 <- caribouHabitat(
  landCover = landCoverD, 
  esker = eskerDshp, 
  linFeat = linFeatDshp, 
  projectPoly = projectPolyD2,
  caribouRange = "Nipigon", 
  padProjPoly = TRUE
)

## ----inspect padded, fig.width=8, fig.height=5--------------------------------
tmap::qtm(landCoverD, raster = "black")+
    tmap::tm_shape(carHab2@landCover)+
    tmap::tm_raster(style = "cat", 
              palette = tmaptools::get_brewer_pal("Accent", n = 9, plot = FALSE), 
              labels = resTypeCode$ResourceType,
              title = "PLC")+
    tmap::tm_legend(bg.color = "white", legend.outside = TRUE)+
  tmap::qtm(carHab2@projectPoly, fill = NULL, borders = "black")

## ----compare pad, fig.width=8, fig.height=5-----------------------------------
carHab3 <- caribouHabitat(
  landCover = landCoverD, 
  esker = eskerDshp, 
  linFeat = linFeatDshp, 
  projectPoly = projectPolyD2,
  caribouRange = "Nipigon"
)

carHab4 <- caribouHabitat(
  landCover = landCoverD, esker = eskerDshp, 
  linFeat = linFeatDshp,
  projectPoly = projectPolyD2,
  caribouRange = "Nipigon", 
  padProjPoly = FALSE, 
  padFocal = TRUE
)

st_area(projectPolyD2)


plot(carHab2, season = "Fall", title = "Pad with data outside project", 
     raster.breaks = c(0, 0.025, 0.05, 0.1, 0.15, 0.2, 0.3, 0.4, 0.5, 1), 
     layout.legend.outside = TRUE)+
  tmap::qtm(carHab3@projectPoly, fill = NULL, borders = "red", 
            shape.is.master = TRUE)

plot(carHab3, season = "Fall", title = "No padding", 
     raster.breaks = c(0, 0.025, 0.05, 0.1, 0.15, 0.2, 0.3, 0.4, 0.5, 1),
     layout.legend.outside = TRUE)+
  tmap::qtm(carHab3@projectPoly, fill = NULL, borders = "red", 
            shape.is.master = TRUE)

plot(carHab4, season = "Fall", title = "Pad with 0 outside project", 
     raster.breaks = c(0, 0.025, 0.05, 0.1, 0.15, 0.2, 0.3, 0.4, 0.5, 1),
     layout.legend.outside = TRUE)+
  tmap::qtm(carHab3@projectPoly, fill = NULL, borders = "red", 
            shape.is.master = TRUE)


## ----carbiouHabitat4----------------------------------------------------------
carHab4 <- caribouHabitat(
  landCover = landCoverD, 
  esker = eskerDshp, 
  natDist = natDistD,
  anthroDist = anthroDistD,
  linFeat = list(roads = linFeatDshp, rail = railD, utilities = utilitiesD),
  projectPoly = projectPolyD,
  caribouRange = "Nipigon"
)

## ----updateCaribou, fig.width=6, fig.height=6---------------------------------
# Create series of data sets
ext <- raster::extent(linFeatDras)

height <- dim(linFeatDras)[1]/4

linFeatDras1 <- linFeatDras[1:height, , drop = FALSE] %>%
  raster::extend(linFeatDras, value = 0)
linFeatDras2 <- linFeatDras[1:(height*2), , drop = FALSE] %>%
  raster::extend(linFeatDras, value = 0)
linFeatDras3 <- linFeatDras[1:(height*3), , drop = FALSE] %>%
  raster::extend(linFeatDras, value = 0)

par(mfrow = c(2, 2))
plot(linFeatDras1)
plot(linFeatDras2)
plot(linFeatDras3)
plot(linFeatDras)

# Run caribouHabitat to process all the data once
# Use Missisa range because roads have a larger effect in that model
carHabLF1 <- caribouHabitat(
  landCover = landCoverD,
  esker = eskerDras,
  natDist = natDistD, 
  anthroDist = anthroDistD, 
  linFeat = linFeatDras1, 
  projectPoly = projectPolyD, 
  caribouRange = "Missisa", 
  padFocal = TRUE
)

# Run updateCaribou with the new linFeat raster
carHabLF2 <- updateCaribou(carHabLF1, newData = list(linFeat = linFeatDras2))

# compare results
plot(carHabLF1, season = "Spring", title = "linFeat 1", raster.breaks = 0:10/10, 
     legend.outside = TRUE)
plot(carHabLF2, season = "Spring", title = "linFeat 2", raster.breaks = 0:10/10, 
     legend.outside = TRUE)



## ---- fig.width=8, fig.height=5-----------------------------------------------

linFeatScns <- lst(linFeatDras2, linFeatDras3, linFeatDras)

# using carHabLF1 created above we run the update for all three datasets

linFeatResults <- purrr::map(
  linFeatScns,
  ~updateCaribou(carHabLF1, newData = list(linFeat = .x))
)

purrr::walk2(c(carHabLF1, linFeatResults), 
             c("linFeatDras1", names(linFeatResults)), 
             ~plot(.x, season = "Spring", title = .y, raster.breaks = 0:10/10,
                   legend.outside = TRUE) %>% print())



## ----update, fig.width=8, fig.height=5----------------------------------------
carHab1@attributes$caribouRange$coefRange <- "Missisa"

misCoef <- updateCaribou(carHab1)

plot(misCoef)

## -----------------------------------------------------------------------------
carHabStd <- caribouHabitat(
  landCover = landCoverD,
  esker = eskerDras,
  natDist = natDistD, 
  anthroDist = anthroDistD, 
  linFeat = linFeatDras, 
  projectPoly = projectPolyD, 
  caribouRange = "James Bay", 
  coefTable = coefTableStd,
  doScale = TRUE
)

## ----binUse, fig.width=8, fig.height=5----------------------------------------
binCarHab1 <- calcBinaryUse(carHab1)
binCarHab1Seasons <- calcBinaryUse(carHab1, bySeason = TRUE)
tmap::qtm(binCarHab1)
tmap::qtm(binCarHab1Seasons)

## -----------------------------------------------------------------------------

res <- loadSpatialInputs(projectPoly = projectPolyD2, refRast = landCoverD,
                        inputsList = list(esker = eskerDshp, 
                                          linFeatRas = list(linFeatDshp, railD, 
                                                            utilitiesD),
                                          linFeatLine = list(linFeatDshp, railD, 
                                                             utilitiesD),
                                          natDist = natDistD,
                                          anthroDist = anthroDistD),
                        convertToRastDens = c("esker", "linFeatRas"),
                        useTemplate = c("esker", "linFeatRas"),
                        altTemplate = raster(landCoverD) %>% 
                          raster::`res<-`(c(400, 400)),
                        bufferWidth = 10000)

str(res, max.level = 1)

resCH <- res
resCH$linFeatLine <- NULL
names(resCH) <- gsub("linFeatRas", "linFeat", names(resCH))

carHab5 <- caribouHabitat(preppedData = resCH, caribouRange = "Nipigon")

resDM <- res
resDM$linFeatRas <- NULL
names(resDM) <- gsub("linFeatLine", "linFeat", names(resDM))

distMets <- disturbanceMetrics(preppedData = resDM)


