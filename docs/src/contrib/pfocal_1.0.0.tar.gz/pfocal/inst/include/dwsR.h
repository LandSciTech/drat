#ifndef RCPP_pfocal_H__
#define RCPP_pfocal_H__

//This is where any imports required to make the exported functions go

#endif // RCPP_pfocal_H__
