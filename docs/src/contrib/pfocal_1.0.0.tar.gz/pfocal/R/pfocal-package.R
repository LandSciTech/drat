#' @keywords internal
#' @name pfocal-package
#' @aliases pfocal-package
"_PACKAGE"

# The following block is used by usethis to automatically manage
# roxygen namespace tags. Modify with care!
## usethis namespace: start
#' @useDynLib pfocal, .registration = TRUE
#' @importFrom Rcpp sourceCpp
## usethis namespace: end
NULL
