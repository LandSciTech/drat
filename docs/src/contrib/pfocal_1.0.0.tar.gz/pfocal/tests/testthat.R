library(testthat)
library(pfocal)

test_check("pfocal")
